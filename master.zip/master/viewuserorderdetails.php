<?php

session_start();
$_SESSION['currentpage'] = "userorderdetails";

$pagetitle = "View Your Order Details";

require_once 'header.php';
require_once 'connect.php';

$custid = $_SESSION['frontloginid'];
$ticketid = $_POST['ticketid'];
$visible = 1;



$sqlselect = " SELECT m.dbmenuitemname, td.dbticketpricecharged, td.dbticketnotes FROM menu m, ticketdetail td 
                WHERE dbticketid = :bvticketid AND td.dbmenuid = m.dbmenuid";
$result_tds = $db->prepare($sqlselect);
$result_tds->bindValue(':bvticketid', $ticketid);
$result_tds->execute();

if(isset($_SESSION['frontloginid']))
{
?>

    <br>

    <div class="container bg-white rounded-lg">
        <br>
        <center><h2 class="text-warning font-weight-bold">Order #<?php echo $ticketid; ?> Details</h2></center>

        <br>

        <center>
            <table class="table table-responsive-sm w-auto">

                <thead class="thead-light">
                <tr>
                    <th>Item&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
                    <th>Price&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
                    <th>Notes&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
                </tr>
                </thead>
                <tbody>
                <?php
                $tickettotal = 0;
                while($rowtds = $result_tds->fetch())
                {
                    $tickettotal = $tickettotal + $rowtds['dbticketpricecharged'];

                    echo '<tr><td>' . $rowtds['dbmenuitemname'] . '</td>';
                    echo '<td>' . $rowtds['dbticketpricecharged'] . '</td>';
                    echo '<td>' . $rowtds['dbticketnotes'] . '</td></tr>';
                }
                ?>
                <tr class="bg-light"><th></th><th></th><th></th></tr>
                <tr>
                    <th>Subtotal:</th>
                    <th><?php
                        setlocale(LC_MONETARY, "en_US");
                        echo money_format('%(#10n',$tickettotal);
                        ?>
                    </th>
                </tr>
                <tr>
                    <th>Tax:</th>
                    <th><?php
                        setlocale(LC_MONETARY, "en_US");
                        echo money_format('%(#10n',($tickettotal * 0.08));
                        ?>
                    </th>
                </tr>
                <tr>
                    <th>Total:</th>
                    <th><?php
                        setlocale(LC_MONETARY, "en_US");
                        echo money_format('%(#10n',($tickettotal * 1.08));
                        ?>
                    </th>
                </tr>
                </tbody>

            </table>
        </center>
    </div><br>

<?php
}
include_once 'footer.php';
?>