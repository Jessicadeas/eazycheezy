<!--No php needs to be called in this page. This page simply closes all remaining div elements and the body tag.
    Also includes the information for the footer, which has the address, hours of operation, phone number, and
    social media links. -->
</div>
<footer id="footer" class="container-fluid text-center p-2"
        style="background-image: url(images/footerFlooring.jpg);  background-size: 100% 100%">

    <div class="container justify-content-center">

        <div class="row text-white text-sm-left" style="font-family: AvenirLTStd-Roman">

            <div class="col col-lg">
                <span class="text-warning text-uppercase font-weight-bold">Location</span>
                <p style="font-size:85%">EZ Cheezy</p>
                <p style="font-size:85%">123 Main St</p>
                <p style="font-size:85%">Conway, SC</p>
            </div>

            <div class="col col-lg">
                <span class="text-warning text-uppercase font-weight-bold">Hours</span>
                <p style="font-size:85%">Sunday - Thursday: 10 AM - 10 PM</p>
                <p style="font-size:85%">Friday & Saturday: 10 AM - 12 AM</p>
            </div>

            <div class="col col-lg">
                <span class="text-warning text-uppercase font-weight-bold">Reservations</span>
                <p style="font-size:85%">(843) 123-4567</p>
            </div>

            <div class="col col-lg">
                <span class="text-warning text-uppercase font-weight-bold">Follow Us</span>
                <br>
                <a href="https://www.instagram.com/explore/tags/ezcheezy/" target="_blank">
                    <img src="images/instagram_icon_orange.png" width="45" height="45"></a>
                <a href="https://www.facebook.com/ezcheezytruck/" target="_blank">
                    <img src="images/facebook_icon_orange.png" width="45" height="45"></a>
            </div>

        </div>

        <div class="text-white text-lg-center">
            <h6>Copyright &copy; 2019 EZ Cheezy<br>
            </h6>
        </div>

    </div>

</footer>
</div>
</body>
</html>