<?php
session_start();
$_SESSION['currentpage'] = "enterticketdetails";

$pagetitle = "Enter Order Details";

require_once 'header.php';
require_once 'connect.php';

//NECESSARY VARIABLES
$item_err = "";
$ticketid_err = "";
$price_err = "";

$formfield['ffticketid'] = $_POST['ticketid'];
$formfield['ffticketdetailid'] = $_POST['ticketdetailid'];
$formfield['ffmenuid'] = $_POST['menuid'];
$formfield['ffticketitemprice'] = $_POST['ticketitemprice'];

// get the categories for items
$selectcats = "SELECT * FROM category";
$resultcats = $db->prepare($selectcats);
$resultcats->execute();

// enter ticket item
if(isset($_POST['OIEnter']))
{
    $sqlinsert = 'INSERT INTO ticketdetail (dbticketid, dbmenuid, dbticketpricecharged, dbticketitemopen)
                                  VALUES (:bvticketid, :bvmenuid, :bvticketpricecharged, 1)';
    $stmtinsert = $db->prepare($sqlinsert);
    $stmtinsert->bindValue(':bvticketid', $formfield['ffticketid']);
    $stmtinsert->bindValue(':bvmenuid', $formfield['ffmenuid']);
    $stmtinsert->bindValue(':bvticketpricecharged', $formfield['ffticketitemprice']);
    $stmtinsert->execute();
	
	$sqlupdatein = 'UPDATE inventory
				SET dbinvamount = dbinvamount - 1
					WHERE dbmenuid = :bvmenuid';
			$stmtupdatein = $db->prepare($sqlupdatein);
			$stmtupdatein->bindValue(':bvmenuid', $formfield['ffmenuid']);
			$stmtupdatein->execute();
}

// delete item
if(isset($_POST['DeleteItem']))
{
	$formfield['ffmenuid'] = $_POST['menuid'];
	
    $sqldelete = 'DELETE FROM ticketdetail WHERE dbticketdetailid = :bvticketdetailid';
    $stmtdelete = $db->prepare($sqldelete);
    $stmtdelete->bindValue(':bvticketdetailid', $formfield['ffticketdetailid']);
    $stmtdelete->execute();
	
		$sqlupdatein = 'UPDATE inventory
					SET dbinvamount = dbinvamount + 1
						WHERE dbmenuid = :bvmenuid';
				$stmtupdatein = $db->prepare($sqlupdatein);
				$stmtupdatein->bindValue(':bvmenuid', $formfield['ffmenuid']);
				$stmtupdatein->execute();
}

// update item
if(isset($_POST['UpdateItem']))
{
    $formfield['ffticketitemnotes'] = trim($_POST['newnote']);
    $formfield['ffticketdetailid'] = $_POST['ticketdetailid'];
    $sqlupdateoi = 'UPDATE ticketdetail
                        SET dbticketnotes = :bvticketnotes
                        WHERE dbticketdetailid = :bvticketdetailid';
    $stmtupdateoi = $db->prepare($sqlupdateoi);
    $stmtupdateoi->bindValue(':bvticketnotes', $formfield['ffticketitemnotes']);
    $stmtupdateoi->bindValue(':bvticketdetailid', $formfield['ffticketdetailid']);
    $stmtupdateoi->execute();
}

$sqlselecto = "SELECT ticketdetail.*, menu.dbmenuitemname, inventory.dbinvamount
                FROM ticketdetail, menu, inventory
                WHERE menu.dbmenuid = ticketdetail.dbmenuid
                AND ticketdetail.dbticketid = :bvticketid
				AND inventory.dbmenuid = menu.dbmenuid";
$resulto = $db->prepare($sqlselecto);
$resulto->bindValue(':bvticketid', $formfield['ffticketid']);
$resulto->execute();

if(isset($_SESSION['frontloginid']) && isset($formfield['ffticketid'])) {
    ?>
<div style="width:90%;margin-left:5%;margin-right:5%">
<fieldset><legend><h2 class="text-white">Enter Items for Order Number: <?php echo $formfield['ffticketid'] ; ?></h2></legend>

    <script>
        $(function() {
            $('[data-toggle="tooltip"]').tooltip();
        });
    </script>

    <div class="container-fluid">
        <div class="row">
            <?php
            while($rowc = $resultcats->fetch())
            {

                if($rowc['dbcatid'] != 7 && $rowc['dbcatid'] != 8)
                {
                    echo '<div class="c col-lg-auto d-lg-inline-block text-center" style="font-family: AvenirLTStd-Roman">';
                    echo '<h4 class="text-warning text-lowercase" style="font-family: Baron-Neue">' . $rowc['dbcatname'] . '</h4><br>';

                    $sqlselectp = "SELECT * FROM menu, inventory WHERE dbcatid = :bvcatid AND menu.dbmenuid = inventory.dbmenuid";
                    $resultp = $db->prepare($sqlselectp);
                    $resultp->bindValue(':bvcatid', $rowc['dbcatid']);
                    $resultp->execute();

                    while($rowp = $resultp->fetch())
                    {
                        echo    '<form action="' . $_SERVER['PHP_SELF'] . '" method="post">';
                        echo    '<input type="hidden" name="ticketid" value="' . $formfield['ffticketid'] . '">';
                        echo    '<input type="hidden" name="menuid" value="' . $rowp['dbmenuid'] . '">';
                        echo    '<input type="hidden" name="ticketitemprice" value="' . $rowp['dbmenuitemprice'] . '">';

                        $invamount = $rowp['dbinvamount'];

                        if($invamount < 1){
                            echo    '<input type="submit" name="OIEnter" class="w-100 btn-sm btn-danger font-weight-bold" 
								style="font-family: AvenirLTStd-Roman" data-toggle="tooltip" data-placement="bottom" title="' . $rowp['dbmenuitemdescr'] . '" value="' . $rowp['dbmenuitemname'] . ' - $' . $rowp['dbmenuitemprice'] . '" disabled>';

                        }else{
                            echo    '<input type="submit" name="OIEnter" class="w-100 btn-sm btn-light font-weight-bold" 
								style="font-family: AvenirLTStd-Roman" data-toggle="tooltip" data-placement="bottom" title="' . $rowp['dbmenuitemdescr'] . '" value="' . $rowp['dbmenuitemname'] . ' - $' . $rowp['dbmenuitemprice'] . '">';

                        }




                        echo    '</form>';
                    }
                    echo '</div>';
                }

            }
            ?>
        </div>
    </div>


</fieldset>
<br><br>
    <table class="table-responsive-md bg-white">
        <tr>
        <td>
        <table class="table table-hover">
            <thead class="thead-light">
            <tr>
                <th>Item</th>
                <th>Price</th>
                <th>Notes</th>
                <th></th>
                <th></th>
            </tr>
            </thead>
                <tbody>
                <?php
                    $tickettotal = 0;
                    while($rowo = $resulto->fetch())
                    {
                        $tickettotal = $tickettotal + $rowo['dbticketpricecharged'];

                        if($rowo['dbticketitemopen'] == 1) {
                            echo '<tr><td>' . $rowo['dbmenuitemname'] . '</td><td> $ ' . $rowo['dbticketpricecharged'] . '</td>';
                            echo '<td>' . $rowo['dbticketnotes'] . '</td><td>';
                            echo '<form action="' . $_SERVER['PHP_SELF'] . '" method="post">';
                            echo '<input type="hidden" name="ticketid" value="' . $formfield['ffticketid'] . '">';
                            echo '<input type="hidden" name="ticketdetailid" value="' . $rowo['dbticketdetailid'] . '">';
                            echo '<input type="submit" name="NoteEntry" value="Update" class="w-100 btn-sm btn-secondary">';
                            echo '</form></td><td>';
                            echo '<form action="' . $_SERVER['PHP_SELF'] . '" method="post">';
                            echo '<input type="hidden" name="ticketid" value="' . $formfield['ffticketid'] . '">';
                            echo '<input type="hidden" name="ticketdetailid" value="' . $rowo['dbticketdetailid'] . '">';
                            echo '<input type="hidden" name="menuid" value="' . $rowo['dbmenuid'] . '">';
                            echo '<input type="submit" name="DeleteItem" value="Delete" class="w-100 btn-sm btn-secondary">';
                            echo '</form></td></tr>';
                        } else {
                            echo '<tr data-toggle="tooltip" data-placement="right" title="Cannot update or remove item. This item has already been made."><td>' . $rowo['dbmenuitemname'] . '</td><td> $ ' . $rowo['dbticketpricecharged'] . '</td>';
                            echo '<td>' . $rowo['dbticketnotes'] . '</td><td>';
                            echo '<form action="' . $_SERVER['PHP_SELF'] . '" method="post">';
                            echo '<input type="hidden" name="ticketid" value="' . $formfield['ffticketid'] . '">';
                            echo '<input type="hidden" name="ticketdetailid" value="' . $rowo['dbticketdetailid'] . '">';
                            echo '<input type="submit" name="NoteEntry" value="Update" class="w-100 btn-sm btn-secondary" disabled>';
                            echo '</form></td><td>';
                            echo '<form action="' . $_SERVER['PHP_SELF'] . '" method="post">';
                            echo '<input type="hidden" name="ticketid" value="' . $formfield['ffticketid'] . '">';
                            echo '<input type="hidden" name="ticketdetailid" value="' . $rowo['dbticketdetailid'] . '">';
                            echo '<input type="hidden" name="menuid" value="' . $rowo['dbmenuid'] . '">';
                            echo '<input type="submit" name="DeleteItem" value="Delete" class="w-100 btn-sm btn-secondary" disabled>';
                            echo '</form></td></tr>';
                        }

                    }
                ?>
            <tr>
                <th>Total:</th>
                <th><?php
                    setlocale(LC_MONETARY, "en_US");
                    echo money_format('%(#10n',$tickettotal);
                    ?>
                </th>
            </tr>
                </tbody>
        </table>
        <?php
            if(isset($_POST['NoteEntry']))
            {
                $sqlselectoi = "SELECT ticketdetail.*, menu.dbmenuitemname
                                    FROM ticketdetail, menu
                                    WHERE menu.dbmenuid = ticketdetail.dbmenuid
                                    AND ticketdetail.dbticketdetailid = :bvticketdetailid";
                $resultoi = $db->prepare($sqlselectoi);
                $resultoi->bindValue(':bvticketdetailid', $_POST['ticketdetailid']);
                $resultoi->execute();
                $rowoi = $resultoi->fetch();

                echo '</td><td class="w-50">';
                echo '<form action="' . $_SERVER['PHP_SELF'] . '" method="post">';
                echo '<table class="text-center" style="margin-left:20%">';
                echo '<tr><td>Note: <input class="form-control form-control-md" type="text" maxlength="255" name="newnote" value="' . $rowoi['dbticketnotes'] . '"></td></tr>';
                echo '<tr><td>';
                echo '<input type="hidden" name="ticketid" value="' . $formfield['ffticketid'] . '">';
                echo '<input type="hidden" name="ticketdetailid" value="' . $rowoi['dbticketdetailid'] . '">';
                echo '<input type="submit" name="UpdateItem" value="Update Item" class="btn btn-primary"></td></tr></table>';
            }
        ?>
        </td></tr>
    </table>
</div>
    <br><br>
    <div class="text-center container-fluid">
        <?php
            echo '<form action="completeticket.php" method="post">';
            echo '<input type="hidden" name="ticketid" value="' . $formfield['ffticketid'] . '">';
            echo '<input type="submit" name="CompleteCart" value="Complete Order" class="btn btn-success font-weight-bold">';
            echo '</form>';
        ?>
    </div>
    <br><br>
    <?php
}
include_once 'footer.php';
?>