<?php
require_once "header.php";
require_once "connect.php";

$formfield['ffticketid'] = $_POST['ticketid'];

$sqlselecto = "SELECT ticketdetail.*, menu.dbmenuitemname
			FROM ticketdetail, menu
			WHERE menu.dbmenuid = ticketdetail.dbmenuid
			AND ticketdetail.dbticketid = :bvticketid";
$resulto = $db->prepare($sqlselecto);
$resulto->bindValue(':bvticketid', $formfield['ffticketid']);
$resulto->execute();

?>
    <br>
    <div class="text-center container w-50">
    <h2 class="text-warning">Order #<span class="text-warning font-weight-bold"><?php echo $formfield['ffticketid']; ?></span> has been submitted.  Thank you!</h2>
        <br>
    <table class="table table-hover bg-white">
        <thead class="bg-light">
        <tr>
            <th>Item</th>
            <th>Price</th>
            <th>Notes</th>
        </tr>
        </thead>
        <tbody>
        <?php
        $tickettotal = 0;
        while($rowo = $resulto->fetch())
        {
            $tickettotal = $tickettotal + $rowo['dbticketpricecharged'];

            echo '<tr><td>' . $rowo['dbmenuitemname'] . '</td><td>' . $rowo['dbticketpricecharged'] . '</td>';
            echo '<td>' . $rowo['ticketnotes'] . '</td>';
            echo '</tr>';
        }
        ?>
        <tr class="bg-light"><th></th><th></th><th></th></tr>
        <tr>
            <th>Subtotal:</th>
            <th><?php
                setlocale(LC_MONETARY, "en_US");
                echo money_format('%(#10n',$tickettotal);
                ?>
            </th>
        </tr>
        <tr>
            <th>Tax:</th>
            <th><?php
                setlocale(LC_MONETARY, "en_US");
                echo money_format('%(#10n',($tickettotal * 0.08));
                ?>
            </th>
        </tr>
        <tr>
            <th>Total:</th>
            <th><?php
                setlocale(LC_MONETARY, "en_US");
                echo money_format('%(#10n',($tickettotal * 1.08));
                ?>
            </th>
        </tr>
        </tbody>
    </table>
</div>
<?php
include_once 'footer.php';
?>