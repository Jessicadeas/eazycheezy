<?php
$pagetitle = "Welcome";
require_once 'header.php';
?>

<div class="bgimg-1 ">
    <div class="caption">
        <h1 class="display-3 text-white" style="font-family: Baron-Neue">Welcome</h1>
    </div>
</div>

<div class="container">

    <br>

    <div class="row">
        <div class="col col-6">
            <div id="carouselMenuItems" class="carousel slide shadow-lg" data-ride="carousel">
                <div class="carousel-inner" role="listbox">
                    <div class="carousel-item active">
                        <img class="d-block w-100 rounded-lg"  src="images/heirloom-tomato-gourmet-sandwich.jpg" alt="Second slide">
                    </div>
                    <div class="carousel-item">
                        <img class="d-block w-100 rounded-lg"  src="images/northForkCraftBreweryTour.jpg" alt="Second slide">
                    </div>
                    <div class="carousel-item">
                        <img class="d-block w-100 rounded-lg"  src="images/redwinecheese.jpg" alt="Second slide">
                    </div>
                    <div class="carousel-item">
                        <img class="d-block w-100 rounded-lg"  src="images/wroclaw-craft-beer-tour.jpg" alt="Second slide">
                    </div>
                </div>
            </div>
        </div>
        <div class="col col-6">
            <br>
            <blockquote class="blockquote">
            <p class="text-white">Our goal is to offer a cozy and friendly atmosphere for all ages, and prices to fit any budget.
                Our menu consists of a variety of hot soups, grilled cheese, and other sandwiches as well as desserts.</p>
            </blockquote>
                <br><br>
            <blockquote class="blockquote">
                <p class="mb-0 text-white">Our mission is to bring reasonably priced food to the residents of Horry County and surrounding areas.</p>
                <footer class="blockquote-footer"><cite title="Source Title">EZ Cheezy</cite></footer>
            </blockquote>
        </div>
    </div>
    <br><br>
</div>

<br>

<div class="bgimg-2 ">
    <div class="caption">
        <h1 class="display-3 text-white" style="font-family: Baron-Neue">Are you hungry?</h1>
    </div>
</div>

<br>

<div class="container-fluid">
    <div class="row">
        <div class="col col-6 text-center">
            <div>
                <h2 class="text-white text-uppercase display-4" style="font-family: AvenirLTStd-Roman">Sandwiches</h2>
                <h2 class="text-white text-uppercase display-4" style="font-family: AvenirLTStd-Roman">Soup</h2>
                <h2 class="text-white text-uppercase display-4" style="font-family: AvenirLTStd-Roman">Beer</h2>
                <h2 class="text-white text-uppercase display-4" style="font-family: AvenirLTStd-Roman">Wine</h2>
            </div>
        </div>
        <div class="col col-6 text-center">
            <div>
                <h1 class="text-warning text-uppercase display-3" style="font-family: AvenirLTStd-Roman">Family</h1>
                <h1 class="text-white text-uppercase display-4" style="font-family: AvenirLTStd-Roman">Friends</h1>
                <h1 style="color:yellow; font-family: AvenirLTStd-Roman" class="text-uppercase display-3">A Good Time</h1>
            </div>
        </div>
    </div>
</div>

<br>

<div class="bgimg-3 ">
    <div class="caption">
        <h1 class="display-3 text-white" style="font-family: Baron-Neue">We love all things <span class="text-warning">Cheezy!</span></h1>
    </div>
</div>


<?php
include_once 'footer.php';
?>