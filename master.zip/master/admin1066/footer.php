
</div>
<footer class="container-fluid text-center">
    <div class="container justify-content-center">
        <div class="text-white text-lg-center">
            <h6>Copyright &copy; 2019 EZ Cheezy<br>
            </h6>
        </div>
    </div>
</footer>
</body>
</html>