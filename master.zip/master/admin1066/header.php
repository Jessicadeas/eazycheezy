<?php session_start();
?>
<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="utf-8">
    <!--<link rel="stylesheet" href="styles/ezcheezy.css" />-->
    <link rel="shortcut icon" size="16x16" type="image/x-icon" href="images/fave_icon_EZ.ico?" />
    <link rel="stylesheet" href="styles/bootstrap4-wizardry.css" />
    <link rel="stylesheet" href="styles/datatables.min.css"/>
    <link rel="stylesheet" href="styles/dataTables.bootstrap.min.css" />
    <!-- MDBootstrap Datatables  -->
    <link href="styles/dataTables.bootstrap4.min.css" type="text/css" rel="stylesheet">
    <script src="js/jquery-3.3.1.min.js"></script>
    <!-- MDBootstrap Datatables  -->
    <script type="text/javascript" charset="utf8" src="js/datatables.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="js/bootstrap.js"></script>

</head>

<body style="background-image:url(images/chalkboard.jpg); background-repeat:no-repeat; background-attachment: fixed; background-size: 100% 100%">      <!-- closed in the footer -->
<div style="margin:1%">       <!-- closed in the footer -->

    <div class="row container-fluid border border-white border-left-0 border-top-0 border-right-0 p-2">
        <div class="col container-fluid align-items-end">
            <?php include_once "navbar.php" ?>
        </div>
    </div>



