<?php
session_start();
$_SESSION['currentpage'] = "updateuser";

$pagetitle = "Update Customer Information";

require_once 'header.php';
require_once 'connect.php';

// if the user is logged in, get their info
if(isset($_SESSION['frontloginid']))
{
    // assign custid
    $custid = $_SESSION['frontloginid'];
    $visible = 1;

    // get the customer info
    $selectuser = "SELECT customer.*, locations.dblocationname FROM customer, locations WHERE customer.dbcustid = :bvcustid AND customer.dblocationid = locations.dblocationid";
    $result_user = $db->prepare($selectuser);
    $result_user->bindValue(':bvcustid', $custid);
    $result_user->execute();
    $row_user = $result_user->fetch();

    $formfield['ffemail'] = $row_user['dbcustemail'];
    $formfield['ffpass'] = $row_user['dbcustpass'];
    $formfield['fffirstname'] = $row_user['dbcustfname'];
    $formfield['fflastname'] = $row_user['dbcustlname'];
    $formfield['ffaddress1'] = $row_user['dbcustaddress1'];
    $formfield['ffaddress2'] = $row_user['dbcustaddress2'];
    $formfield['ffcity'] = $row_user['dbcustcity'];
    $formfield['ffstate'] = $row_user['dbcuststate'];
    $formfield['ffzip'] = $row_user['dbcustzip'];
    $formfield['ffphone'] = $row_user['dbcustphone'];
    $formfield['ffmaillist'] = $row_user['dbcustmaillist'];
	$formfield['fflocation'] = $row_user['dblocationid'];


} else {
    $visible = 0;
}

// get the locations
$locations = 'SELECT * FROM locations';
$result_lo = $db->prepare($locations);
$result_lo->execute();

//NECESSARY VARIABLES
$errormsg = "";
$fname_err = $lname_err = $email_err = $pass1_err = $pass2_err = "";
$password_change = 0;
$password = '';

if( isset($_POST['submit']) )
{
    $formfield['ffemail'] = trim($_POST['custemail']);
    $formfield['ffpass1'] = trim($_POST['custpass1']);
    $formfield['ffpass2'] = trim($_POST['custpass2']);
    $formfield['fffirstname'] = trim($_POST['custfname']);
    $formfield['fflastname'] = trim($_POST['custlname']);
    $formfield['ffaddress1'] = trim($_POST['custaddress1']);
    $formfield['ffaddress2'] = trim($_POST['custaddress2']);
    $formfield['ffcity'] = trim($_POST['custcity']);
    $formfield['ffstate'] = trim($_POST['custstate']);
    $formfield['ffzip'] = trim($_POST['custzip']);
    $formfield['ffphone'] = trim($_POST['custphone']);
    $formfield['ffmaillist'] = $_POST['custmaillist'];
	$formfield['fflocation'] = $_POST['location'];

    if(empty($formfield['fffirstname'])){$fname_err = "First name cannot be empty.";}
    if(empty($formfield['fflastname'])){$lname_err = "Last name cannot be empty.";}
    if(empty($formfield['ffemail'])){$email_err = "E-mail cannot be empty.";}
    //VALIDATE THE EMAIL
    if(empty($email_err))
    {
        if (!filter_var($formfield['ffemail'], FILTER_VALIDATE_EMAIL))
        {
            $email_err = "Your email is not valid.";
        } else
        {
            $select_email = "SELECT dbcustid FROM customer WHERE dbcustemail = :bvemail";
            if($select_stmt = $db->prepare($select_email))
            {
                $select_stmt->bindValue(':bvemail', $formfield['ffemail']);
                if($select_stmt->execute()) {
                    if($select_stmt->rowCount() === 1) {
                        while($row = $select_stmt->fetch()) {
                            if($row['dbcustid'] != $_SESSION['frontloginid']) {
                                $email_err = "E-mail is already taken.";
                            }
                        }
                    }
                } else {
                    die("Something went wrong");
                }
            }
            unset($select_stmt);
        }
    }

    if(!empty($formfield['ffpass1']))
    {
        //confirm passwords match
        if ($formfield['ffpass1'] != $formfield['ffpass2']) {
            $pass1_err = $pass2_err = "Your passwords do not match.";
        } else {
            $password_change = 1;
        }
    }


    if(empty($fname_err) && empty($lname_err) &&  empty($email_err) && $password_change == 1)
    {

        $password = $formfield['ffpass1'];
        $options = [
            'cost' => 12,
        ];
        $encpassword = password_hash($password, PASSWORD_BCRYPT, $options);

        try
        {
            $sqlupdate = "UPDATE customer SET dbcustemail = :bvemail,
                                              dbcustpassword = :bvpass,
                                              dbcustfname = :bvfname, 
                                              dbcustlname = :bvlname, 
                                              dbcustaddress1 = :bvaddress1, 
                                              dbcustaddress2 = :bvaddress2, 
                                              dbcustcity = :bvcity, 
                                              dbcuststate = :bvstate, 
                                              dbcustzip = :bvzip,
                                              dbcustphone = :bvphone,
                                              dbcustmaillist = :bvmaillist,
											  dblocationid = :bvlocation
                                           WHERE dbcustid = :bvcustid";
            $sqlupdate = $db->prepare($sqlupdate);
            $sqlupdate->bindValue(':bvcustid', $custid);
            $sqlupdate->bindValue(':bvemail', $formfield['ffemail']);
            $sqlupdate->bindValue(':bvpass', $encpassword);
            $sqlupdate->bindValue(':bvfname', $formfield['fffirstname']);
            $sqlupdate->bindValue(':bvlname', $formfield['fflastname']);
            $sqlupdate->bindValue(':bvaddress1', $formfield['ffaddress1']);
            $sqlupdate->bindValue(':bvaddress2', $formfield['ffaddress2']);
            $sqlupdate->bindValue(':bvcity', $formfield['ffcity']);
            $sqlupdate->bindValue(':bvstate', $formfield['ffstate']);
            $sqlupdate->bindValue(':bvzip', $formfield['ffzip']);
            $sqlupdate->bindValue(':bvphone', $formfield['ffphone']);
            $sqlupdate->bindValue(':bvmaillist', $formfield['ffmaillist']);
            $sqlupdate->bindValue(':bvlocation', $formfield['fflocation']);
            $sqlupdate->execute();

            echo '<br><div class="alert alert-success" style="width:40%; margin: 0 30% 0 30%; text-align:center role="alert">Customer Information Updated Successfully.</div><br>';

        }
        catch(PDOException $e)
        {
            echo 'Error!' .$e->getMessage();
            exit();
        }
    } else if(empty($fname_err) && empty($lname_err) &&  empty($email_err) && $password_change == 0)
    {
        try
        {
            $sqlupdate = "UPDATE customer SET dbcustemail = :bvemail,
                                              dbcustfname = :bvfname, 
                                              dbcustlname = :bvlname, 
                                              dbcustaddress1 = :bvaddress1, 
                                              dbcustaddress2 = :bvaddress2, 
                                              dbcustcity = :bvcity, 
                                              dbcuststate = :bvstate, 
                                              dbcustzip = :bvzip,
                                              dbcustphone = :bvphone,
                                              dbcustmaillist = :bvmaillist,
											  dblocationid = :bvlocation
                                           WHERE dbcustid = :bvcustid";
            $sqlupdate = $db->prepare($sqlupdate);
            $sqlupdate->bindValue(':bvcustid', $custid);
            $sqlupdate->bindValue(':bvemail', $formfield['ffemail']);
            $sqlupdate->bindValue(':bvfname', $formfield['fffirstname']);
            $sqlupdate->bindValue(':bvlname', $formfield['fflastname']);
            $sqlupdate->bindValue(':bvaddress1', $formfield['ffaddress1']);
            $sqlupdate->bindValue(':bvaddress2', $formfield['ffaddress2']);
            $sqlupdate->bindValue(':bvcity', $formfield['ffcity']);
            $sqlupdate->bindValue(':bvstate', $formfield['ffstate']);
            $sqlupdate->bindValue(':bvzip', $formfield['ffzip']);
            $sqlupdate->bindValue(':bvphone', $formfield['ffphone']);
            $sqlupdate->bindValue(':bvmaillist', $formfield['ffmaillist']);
			$sqlupdate->bindValue(':bvlocation', $formfield['fflocation']);
            $sqlupdate->execute();

            echo '<br><div class="alert alert-success" style="width:40%; margin: 0 30% 0 30%; text-align:center role="alert">Customer Information Updated Successfully.</div><br>';

        }
        catch(PDOException $e)
        {
            echo 'Error!' .$e->getMessage();
            exit();
        }
    }
}//if isset submit

if($visible == 1) {
    ?>

    <div class="container">
        <div class="row">
            <div class="col-md-6 mx-auto">
                <div class="card card-body bg-light mt-5">
                    <h2>Update Customer Information</h2>
                    <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>" name="form">

                        <div class="form-group row">
						<label for="custfname">First Name:</label>
                            <input type="text" name="custfname" placeholder="First Name"
                                   class="form-control <?php echo (!empty($fname_err)) ? 'is-invalid' : ''; ?>"
                                   value="<?php if (isset($formfield['fffirstname'])) {
                                       echo $formfield['fffirstname'];
                                   } ?>"/>
                            <span class="invalid-feedback"><?php echo $fname_err; ?></span>
                        </div>
                        <div class="form-group row">
						<label for="custlname">Last Name:</label>
                            <input type="text" name="custlname" placeholder="Last Name"
                                   class="form-control <?php echo (!empty($lname_err)) ? 'is-invalid' : ''; ?>"
                                   value="<?php if (isset($formfield['fflastname'])) {
                                       echo $formfield['fflastname'];
                                   } ?>"/>
                            <span class="invalid-feedback"><?php echo $lname_err; ?></span>
                        </div>
                        <div class="form-group row">
						<label for="custaddress1">Address 1:</label>
                            <input type="text" name="custaddress1" placeholder="Address 1"
                                   class="form-control <?php echo (!empty($address1_err)) ? 'is-invalid' : ''; ?>"
                                   value="<?php if (isset($formfield['ffaddress1'])) {
                                       echo $formfield['ffaddress1'];
                                   } ?>"/>
                            <span class="invalid-feedback"><?php echo $address1_err; ?></span>
                        </div>
                        <div class="form-group row">
						<label for="custaddress2">Address 2:</label>
                            <input type="text" name="custaddress2" placeholder="Address 2" class="form-control"
                                   value="<?php if (isset($formfield['ffaddress2'])) {
                                       echo $formfield['ffaddress2'];
                                   } ?>"/>
                        </div>
                        <div class="form-group row">
						<label for="custcity">City:</label>
                            <input type="text" name="custcity" placeholder="City"
                                   class="form-control <?php echo (!empty($city_err)) ? 'is-invalid' : ''; ?>"
                                   value="<?php if (isset($formfield['ffcity'])) {
                                       echo $formfield['ffcity'];
                                   } ?>"/>
                            <span class="invalid-feedback"><?php echo $city_err; ?></span>
                        </div>
                        <div class="form-group row">
						<label for="custstate">State:</label>
                            <input type="text" name="custstate" placeholder="State"
                                   class="form-control <?php echo (!empty($state_err)) ? 'is-invalid' : ''; ?>"
                                   value="<?php if (isset($formfield['ffstate'])) {
                                       echo $formfield['ffstate'];
                                   } ?>"/>
                            <span class="invalid-feedback"><?php echo $state_err; ?></span>
                        </div>
                        <div class="form-group row">
						<label for="custzip">Zip Code:</label>
                            <input type="text" name="custzip" placeholder="Zip Code"
                                   class="form-control <?php echo (!empty($zip_err)) ? 'is-invalid' : ''; ?>"
                                   value="<?php if (isset($formfield['ffzip'])) {
                                       echo $formfield['ffzip'];
                                   } ?>"/>
                            <span class="invalid-feedback"><?php echo $zip_err; ?></span>
                        </div>
                        <div class="form-group row">
						<label for="custemail">Email:</label>
                            <input type="email" name="custemail" placeholder="E-mail"
                                   class="form-control <?php echo (!empty($email_err)) ? 'is-invalid' : ''; ?>"
                                   value="<?php if (isset($formfield['ffemail'])) {
                                       echo $formfield['ffemail'];
                                   } ?>"/>
                            <span class="invalid-feedback"><?php echo $email_err; ?></span>
                        </div>
                        <div class="form-group row">
						<label for="custphone">Phone:</label>
                            <input type="text" name="custphone" placeholder="Phone"
                                   class="form-control <?php echo (!empty($phone_err)) ? 'is-invalid' : ''; ?>"
                                   value="<?php if (isset($formfield['ffphone'])) {
                                       echo $formfield['ffphone'];
                                   } ?>"/>
                            <span class="invalid-feedback"><?php echo $phone_err; ?></span>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-4 col-form-label" for="location">Preferred Location:</label>
                            <div class="col-sm-8">
                                <select name="location" id="location" required
                                        class="form-control <?php echo (!empty($location_err)) ? 'is-invalid' : ''; ?>">
                                    <option value="">Select Location</option>
                                    <?php
                                    while ($rowlo = $result_lo->fetch())
                                    {
                                        if ($rowlo['dblocationid'] == $formfield['fflocation']) {
                                            $checker = 'selected';
                                        } else {
                                            $checker = '';
                                        }
                                        echo '<option value="' . $rowlo['dblocationid'] . '" ' . $checker . '>' . $rowlo['dblocationname'] . '</option>';
                                    }
                                    ?>
                                </select>
                                <span class="invalid-feedback"><?php echo $location_err; ?></span>
                            </div>
                        </div>
						 <div class="form-group row">
                            <label class="col-sm-4 col-form-label" for="maillist">Join our mail list?:</label>
                            <div class="col-sm-8">
                                <select name="custmaillist" id="custmaillist"
                                        class="form-control <?php echo (!empty($maillist_err)) ? 'is-invalid' : ''; ?>">
                                    <option value="1">Select Yes or No</option>
                                    <option value="1" <?php if(isset($formfield['ffmaillist']))
                                                        {
                                                            if($formfield['ffmaillist'] == 1)
                                                                {
                                                                    echo 'selected';
                                                                }
                                                        }
                                                        ?>>Yes</option>
                                    <option value="0" <?php if(isset($formfield['ffmaillist']))
                                                        {
                                                            if($formfield['ffmaillist'] == 0)
                                                            {
                                                                echo 'selected';
                                                            }
                                                        }
                                                        ?>>No</option>
                                </select>
                                <span class="invalid-feedback"><?php echo $maillist_err; ?></span>
                            </div>
                        </div>
                        <div class="form-group row">
						<label for="custpass1">Password:</label>
                            <input type="password" name="custpass1" placeholder="Password"
                                   class="form-control <?php echo (!empty($pass1_err)) ? 'is-invalid' : ''; ?>"
                                   value="<?php if (isset($formfield['ffpass1'])) {
                                       echo $formfield['ffpass1'];
                                   } ?>"/>
                            <span class="invalid-feedback"><?php echo $pass1_err; ?></span>
                        </div>
                        <div class="form-group row">
						<label for="custpass2">Confirm Password:</label>
                            <input type="password" name="custpass2" placeholder="Confirm Password"
                                   class="form-control <?php echo (!empty($pass2_err)) ? 'is-invalid' : ''; ?>"
                                   value="<?php if (isset($formfield['ffpass2'])) {
                                       echo $formfield['ffpass2'];
                                   } ?>"/>
                            <span class="invalid-feedback"><?php echo $pass2_err; ?></span>
                        </div>
                        <div class="form-row">
                            <div class="col text-center">
                                <input type="submit" value="Update" name="submit" class="btn btn-secondary">
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <br>
    </div>
    <?php
}
include_once 'footer.php';
?>