<?php
session_start();
$_SESSION['currentpage'] = "register";

$pagetitle = "Register";

require_once 'header.php';
require_once 'connect.php';

//NECESSARY VARIABLES
$errormsg = "";
$fname_err = $lname_err = $pass1_err = $pass2_err = $hiredate_err = $phone_err = $email_err = "";
$address1_err = $city_err = $state_err = $zip_err = $position_err = "";
$password = '';

// get the locations
$locations = 'SELECT * FROM locations';
$result_lo = $db->prepare($locations);
$result_lo->execute();

if( isset($_POST['submit']) )
{
    $formfield['fffirstname'] = trim($_POST['BBfirstname']);
    $formfield['fflastname'] = trim($_POST['BBlastname']);
    $formfield['ffemail'] = trim(strtolower($_POST['BBemail']));
    $formfield['ffpass1'] = trim($_POST['BBpass1']);
    $formfield['ffpass2'] = trim($_POST['BBpass2']);
	$formfield['fflocation'] = $_POST['location'];

    if(empty($formfield['fffirstname'])){$fname_err = "First name cannot be empty.";}
    if(empty($formfield['fflastname'])){$lname_err = "Last name cannot be empty.";}
    if(empty($formfield['ffemail'])){$email_err = "E-mail cannot be empty.";}
    //VALIDATE THE EMAIL
    if(empty($email_err))
    {
        if (!filter_var($formfield['ffemail'], FILTER_VALIDATE_EMAIL))
        {
            $email_err = "Your email is not valid.";
        } else
        {
            $select_email = "SELECT dbcustid FROM customer WHERE dbcustemail = :bvemail";
            if($select_stmt = $db->prepare($select_email))
            {
                $select_stmt->bindValue(':bvemail', $formfield['ffemail']);
                if($select_stmt->execute()) {
                    if($select_stmt->rowCount() === 1) {
                        $email_err = "E-mail is already taken.";
                    }
                } else {
                    die("Something went wrong");
                }
            }
            unset($select_stmt);
        }
    }

    if(empty($formfield['ffpass1'])){$pass1_err = "Password cannot be empty.";}
    if(empty($formfield['ffpass2'])){$pass2_err = "Confirm Password cannot be empty.";}
    //confirm passwords match
    if ($formfield['ffpass1'] != $formfield['ffpass2']) {
        $pass1_err = $pass2_err = "Your passwords do not match.";
    }

    if(empty($fname_err) && empty($lname_err) && empty($email_err) &&  empty($pass1_err) && empty($pass2_err))
    {
        $password = $formfield['ffpass1'];
        $options = [
            'cost' => 12,
        ];
        $encpassword = password_hash($password, PASSWORD_BCRYPT, $options);

        try
        {
            $sqlinsert = "INSERT into customer (dbcustfname, dbcustlname, dbcustpassword, dbcustemail, dbcustmaillist, dblocationid)
                        VALUES (:bvfname, :bvlname, :bvpass, :bvemail, 1, :bvlocation)";
            $sqlinsert = $db->prepare($sqlinsert);
            $sqlinsert->bindValue(':bvfname', $formfield['fffirstname']);
            $sqlinsert->bindValue(':bvlname', $formfield['fflastname']);
            $sqlinsert->bindValue(':bvpass', $encpassword);
            $sqlinsert->bindValue(':bvemail', $formfield['ffemail']);
			$sqlinsert->bindValue(':bvlocation', $formfield['fflocation']);
            $sqlinsert->execute();

            echo '<br><div class="alert alert-success" style="width:40%; margin: 0 30% 0 30%; text-align:center role="alert">Account Created</div><br>';
            echo '<div class="text-center"><a href="login.php">Continue</a></div>';
            echo "<br>";

            $formfield['fffirstname'] = '';
            $formfield['fflastname'] = '';
            $formfield['ffemail'] = '';
            $formfield['ffpass1'] = '';
            $formfield['ffpass2'] = '';
        }
        catch(PDOException $e)
        {
            echo 'Error!' .$e->getMessage();
            exit();
        }
    }
}//if isset submit

    ?>

    <div class="container">
        <div class="row">
            <div class="col-md-6 mx-auto">
                <div class="card card-body bg-light mt-5">
                    <h2>Register New Customer</h2>
                    <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>" name="form">
                        <p>All Fields Required</p>
                        <div class="form-group row">
						<label for="BBfirstname">First Name:</label>
                            <input type="text" name="BBfirstname" placeholder="First Name"
                                   class="form-control <?php echo (!empty($fname_err)) ? 'is-invalid' : ''; ?>"
                                   value="<?php if (isset($formfield['fffirstname'])) {
                                       echo $formfield['fffirstname'];
                                   } ?>"/>
                            <span class="invalid-feedback"><?php echo $fname_err; ?></span>
                        </div>
                        <div class="form-group row">
						<label for="BBlastname">Last Name:</label>
                            <input type="text" name="BBlastname" placeholder="Last Name"
                                   class="form-control <?php echo (!empty($lname_err)) ? 'is-invalid' : ''; ?>"
                                   value="<?php if (isset($formfield['fflastname'])) {
                                       echo $formfield['fflastname'];
                                   } ?>"/>
                            <span class="invalid-feedback"><?php echo $lname_err; ?></span>
                        </div>
                        <div class="form-group row">
						<label for="BBemail">Email:</label>
                            <input type="email" name="BBemail" placeholder="E-mail"
                                   class="form-control <?php echo (!empty($email_err)) ? 'is-invalid' : ''; ?>"
                                   value="<?php if (isset($formfield['ffemail'])) {
                                       echo $formfield['ffemail'];
                                   } ?>"/>
                            <span class="invalid-feedback"><?php echo $email_err; ?></span>
                        </div>
						  <div class="form-group row">
                              <label class="col-sm-4 col-form-label" for="location">Preferred Location:</label>
                              <div class="col-sm-8">
                                  <select name="location" id="location" required
                                          class="form-control <?php echo (!empty($position_err)) ? 'is-invalid' : ''; ?>">
                                      <option value="">Select Location</option>
                                      <?php
                                      while ($rowlo = $result_lo->fetch())
                                      {
                                          if ($rowlo['dblocationid'] == $formfield['fflocation']) {
                                              $checker = 'selected';
                                          } else {
                                              $checker = '';
                                          }
                                          echo '<option value="' . $rowlo['dblocationid'] . '" ' . $checker . '>' . $rowlo['dblocationname'] . '</option>';
                                      }
                                      ?>
                                  </select>
                                  <span class="invalid-feedback"><?php echo $position_err; ?></span>
                              </div>
                        </div>
                        <div class="form-group row">
						<label for="BBpass1">Password:</label>
                            <input type="password" name="BBpass1" placeholder="Password"
                                   class="form-control <?php echo (!empty($pass1_err)) ? 'is-invalid' : ''; ?>"
                                   value="<?php if (isset($formfield['ffpass1'])) {
                                       echo $formfield['ffpass1'];
                                   } ?>"/>
                            <span class="invalid-feedback"><?php echo $pass1_err; ?></span>
                        </div>
                        <div class="form-group row">
						<label for="BBpass2">Confirm Password:</label>
                            <input type="password" name="BBpass2" placeholder="Confirm Password"
                                   class="form-control <?php echo (!empty($pass2_err)) ? 'is-invalid' : ''; ?>"
                                   value="<?php if (isset($formfield['ffpass2'])) {
                                       echo $formfield['ffpass2'];
                                   } ?>"/>
                            <span class="invalid-feedback"><?php echo $pass2_err; ?></span>
                        </div>
                        <div class="form-row">
                            <div class="col text-center">
                                <input type="submit" value="Submit" name="submit" class="btn btn-secondary">
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <br>
    </div>
    <?php

include_once 'footer.php';
?>