<?php
session_start();
$_SESSION['currentpage'] = "View Our Daily Hours of Operation";

$pagetitle = "View Our Daily Hours of Operation";

require_once 'header.php';
require_once 'connect.php';

$formfield['ffhourkey'] = $_POST['hourkey'];
$formfield['ffhoursopen'] = $_POST['opentime'];
$formfield['ffhoursclosed'] = $_POST['closetime'];
$formfield['ffsetopen'] = $_POST['setopen'];
$formfield['ffsetclosed'] = $_POST['setclose'];



$change = 1;


if( isset($_POST['update']))
{
	$formfield['ffhourkey'] = $_POST['hourkey'];
	$formfield['ffhoursopen'] = $_POST['opentime'];
	$formfield['ffhoursclosed'] = $_POST['closetime'];
	$formfield['ffsetopen'] = $_POST['setopen'];
	$formfield['ffsetclosed'] = $_POST['setclose'];
	
	$sql = "UPDATE hours SET dbhoursopen = :bvopen,
							 dbhoursclosed = :bvclosed
							 WHERE dbhourskey = :bvhourskey";
	$resulths = $db->prepare($sql);
	$resulths->bindValue(':bvopen', $formfield['ffsetopen']);
	$resulths->bindValue(':bvclosed', $formfield['ffsetclosed']);
	$resulths->bindValue(':bvhourskey', $formfield['ffhourkey']);
	$resulths->execute();
}


if( isset($_POST['changehours']))
{
	$change = 0;
	
	$sqlselecthk = "SELECT *
	FROM hours 
	WHERE dbhourskey = :bvhourskey";
	$resulthk = $db->prepare($sqlselecthk);
	$resulthk->bindValue(':bvhourskey', $formfield['ffhourkey']);
	$resulthk->execute();
}

$sqlselecth = "SELECT *
	FROM hours ";
$resulth = $db->prepare($sqlselecth);
$resulth->execute();


			
			



if(isset($_SESSION['frontloginname'])) {
	if($change != 0){
    ?>
    <br>
<div class="bg-white p-2 rounded-lg" style="width:35%;margin-left:32%;margin-right:5%">
<br><br>
    <table class="table-responsive-md" align="center">
        <tr>
        <td>
        <table class="table table-hover">
            <thead class="thead-light">
            <tr>
                <th>Day</th>
                <th>Opens</th>
				<th>Closes</th>
            </tr>
            </thead>
                <tbody>
                <?php
					
					
						while($rowh = $resulth->fetch())
						{
								echo '<tr><td>' . $rowh['dbhoursday'] . '</td><td>' . $rowh['dbhoursopen'] . '</td>';
								echo '<td>' . $rowh['dbhoursclosed'] . '</td><tr>';
							
							
						}
	}			
                ?>
                </tbody>
        </table>
        <?php
            
        ?>
        </td></tr>
    </table>

</div>

    <?php
}
include_once 'footer.php';
?>