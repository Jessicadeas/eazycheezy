<?php
$pagetitle = "Reservations";
require_once 'header.php';
?>

    <center>
        <br>
        <div>
            <h2 class="text-white">Under Construction.<br>
                Sorry. Please Check Back Later.</h2>
        </div>
        <br>
    </center>


<?php
include_once 'footer.php';
?>