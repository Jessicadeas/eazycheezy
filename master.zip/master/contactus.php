<?php
$pagetitle = "Contact Us";
require_once 'header.php';
require_once 'connect.php';

$name_err = $email_err = $subject_err = $content_err = "";

if(isset($_POST['submit'])) {
    $formfield['ffname'] = trim($_POST['BBname']);
    $formfield['ffemail'] = trim($_POST['BBemail']);
    $formfield['ffsubject'] = trim($_POST['BBsubject']);
    $formfield['ffcontent'] = trim($_POST['BBcontent']);

    if(empty($formfield['ffname'])) { $name_err = "Please enter first and last name"; }
    if(empty($formfield['ffemail'])) { $email_err = "Please enter email"; }
    if(empty($formfield['ffsubject'])) { $subject_err = "Please enter a subject line for your message"; }
    if(empty($formfield['ffcontent'])) { $content_err = "Please enter your message content"; }

    if(empty($name_err) && empty($email_err) && empty($subject_err) && empty($content_err)) {
        $sqlinsert = "INSERT INTO messages (dbmessagename, dbmessageemail, dbmessagesubject, dbmessagecontent) 
                        VALUES (:bvname, :bvemail, :bvsubject, :bvcontent)";
        $result = $db->prepare($sqlinsert);
        $result->bindValue(':bvname', $formfield['ffname']);
        $result->bindValue(':bvemail', $formfield['ffemail']);
        $result->bindValue(':bvsubject', $formfield['ffsubject']);
        $result->bindValue(':bvcontent', $formfield['ffcontent']);
        $result->execute();

        echo '<br><div class="alert alert-success" style="width:40%; margin: 0 30% 0 30%; text-align:center role="alert">Thank you for your message. We will get back to you at the Email provided shortly.</div><br>';
    }
}


?>
<br><br>

<div class="container">
    <h2 class="text-white text-center" style="font-family: AvenirLTStd-Roman">Contact Us</h2>
    <br>
    <div class="row">
        <div class="col col-lg">
            <div class="card">
                <div class="card-body">
                    <h2 class="card-title text-warning text-uppercase" style="font-family: AvenirLTStd-Roman">Information</h2>
                    <hr>
                    <div class="row">
                        <div class="col-lg-8">
                            <span class="font-weight-bold">Hours</span>
                            <p style="font-size:85%">Sunday - Thursday: 10 AM - 10 PM</p>
                            <p style="font-size:85%">Friday & Saturday: 10 AM - 12 AM</p>
                        </div>
                        <div class="col-lg-4">
                            <span class="font-weight-bold">Directions</span>
                            <p style="font-size:85%">123 Main St</p>
                            <p style="font-size:85%">Conway, SC</p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-8">
                            <span class="font-weight-bold">Phone</span>
                            <p style="font-size:85%"><a href="tel:843-123-4567">(843) 123-4567</a></p>
                        </div>
                        <div class="col-lg-4">
                            <span class="font-weight-bold">Follow Us</span>
                            <br>
                            <a href="https://www.instagram.com/explore/tags/ezcheezy/" target="_blank"><img src="images/instagram_icon.png" width="45" height="45"></a>
                            <a href="https://www.facebook.com/ezcheezytruck/" target="_blank"><img src="images/facebook_icon.png" width="45" height="45"></a>
                        </div>
                    </div>
                </div>
                <hr>
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3314.160610782697!2d-79.04734518448383!3d33.83396843664777!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8900129904262587%3A0x8f12aabf84467312!2s123+Main+St%2C+Conway%2C+SC+29526!5e0!3m2!1sen!2sus!4v1554917040706!5m2!1sen!2sus" width="100%" height="450px" frameborder="0" style="border:0" allowfullscreen></iframe>
            </div>
        </div>
        <div class="col col-lg">
            <div class="card">
                <div class="card-body">
                    <h2 class="card-title text-warning text-uppercase" style="font-family: AvenirLTStd-Roman">Message Us</h2>
                    <hr>
                    <p class="card-subtitle mb-2 text-muted">
                        Let us know how we're doing. Or if you have any questions, send us a message and we will
                        get back to you as soon as possible.
                    </p>
                    <br>
                    <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>" name="form">
                        <div class="form-group row">
                                <input type="text" maxlength="255" name="BBname" placeholder="First & Last Name*"
                                       class="col form-control <?php echo (!empty($name_err)) ? 'is-invalid' : ''; ?>"
                                       value="<?php if (isset($formfield['ffname'])) {
                                           echo $formfield['ffname'];
                                       } ?>"/>
                                <span class="invalid-feedback"><?php echo $fname_err; ?></span>


                                <input type="email" maxlength="255" name="BBemail" placeholder="Email Address*"
                                       class="col form-control <?php echo (!empty($email_err)) ? 'is-invalid' : ''; ?>"
                                       value="<?php if (isset($formfield['ffemail'])) {
                                           echo $formfield['ffemail'];
                                       } ?>"/>
                                <span class="invalid-feedback"><?php echo $email_err; ?></span>

                        </div>
                        <div class="form-group row">
                            <input type="text" maxlength="255" name="BBsubject" placeholder="Email Subject*"
                                   class="form-control <?php echo (!empty($subject_err)) ? 'is-invalid' : ''; ?>"
                                   value="<?php if (isset($formfield['ffsubject'])) {
                                       echo $formfield['ffsubject'];
                                   } ?>"/>
                            <span class="invalid-feedback"><?php echo $subject_err; ?></span>
                        </div>
                        <div class="form-group row">
                            <textarea rows="4" maxlength="10000" name="BBcontent" placeholder="Questions, Comments, Concerns?*"
                                   class="form-control <?php echo (!empty($content_err)) ? 'is-invalid' : ''; ?>"
                                   value="<?php if (isset($formfield['ffcontent'])) {
                                       echo $formfield['ffcontent'];
                                   } ?>"></textarea>
                            <span class="invalid-feedback"><?php echo $content_err; ?></span>
                        </div>
                        <div class="form-row">
                            <div class="col text-center">
                                <input type="submit" value="Message Us" name="submit" class="btn btn-secondary">
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<br>


<?php
require_once 'footer.php';

?>
