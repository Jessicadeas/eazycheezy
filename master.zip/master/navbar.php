<?php
/* This page utilizes php to determine if the SESSION variable 'frontloginid' is set. If the user is logged in to the
    front-end, it displays a slightly different navigation than if the user wasn't logged in. It offers a small
    greeting.*/
if(isset($_SESSION['frontloginid']))
{
?>

<!--Using bootstrap classes, this navbar is dynamic in that when the page is visited on smaller
    viewports, a collapsable button replaces the navbar which can be pressed to expand/collapse the
    navigation links. -->
<nav class="navbar navbar-expand-lg navbar-dark text-white">
    <button class="navbar-toggler" type="button" data-toggle="collapse"
            data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
            aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="nav">
            <li class="nav-item text-white text-uppercase">
                <a href="index.php"
                       class="p1-lg-0 p-3 text-white text-uppercase" style="font-size: 1.8vw">Home</a>
            </li>
            <li class="nav-item text-white text-uppercase">
                <a href="viewmenu.php"
                       class="p1-lg-0 p-3 text-white text-uppercase" style="font-size: 1.8vw">Menu</a>
            </li>
            <li class="nav-item text-white text-uppercase">
                <a href="insertticket.php"
                       class="p1-lg-0 p-3 text-white text-uppercase" style="font-size: 1.8vw">Order</a>
            </li>
            <li class="nav-item text-white text-uppercase">
                <a href="contactus.php"
                       class="p1-lg-0 p-3 text-white text-uppercase" style="font-size: 1.8vw">Contact&nbsp;Us</a>
            </li>
            <li class="nav-item text-white text-uppercase">
                <a href="updateuser.php"
                       class="p1-lg-0 p-3 text-white text-uppercase" style="font-size: 1.8vw">User&nbsp;Information</a>
            </li>
            <li class="nav-item text-white text-uppercase">
                <a href="userorders.php"
                   class="p1-lg-0 p-3 text-white text-uppercase" style="font-size: 1.8vw">User&nbsp;Orders</a>
            </li>
            <li class="nav-item text-white text-uppercase">
                <a href="logout.php"
                       class="p1-lg-0 p-3 text-white text-uppercase" style="font-size: 1.8vw">Logout</a>
            </li>

        </ul>
    </div>



</nav>

<?php
} else {
?>

<!--This secondary navbar is what a user would see if he or she does not login to an account while visiting
    our website. Has much the same functionality as above, but doesn't greet the user with their name. -->
<nav class="navbar navbar-expand-lg navbar-dark text-white">
    <button class="navbar-toggler" type="button" data-toggle="collapse"
            data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
            aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="nav">
            <li class="nav-item text-white text-uppercase">
                <a href="index.php" class="p1-lg-0 p-3 text-white text-uppercase" style="font-size: 1.8vw">Home</a>
            </li>
            <li class="nav-item text-white text-uppercase">
                <a href="viewmenu.php" class="p1-lg-0 p-3 text-white text-uppercase" style="font-size: 1.8vw">Menu</a>
            </li>
            <li class="nav-item text-white text-uppercase">
                <a href="contactus.php" class="p1-lg-0 p-3 text-white text-uppercase" style="font-size: 1.8vw">Contact&nbsp;Us</a>
            </li>
            <li class="nav-item text-white text-uppercase">
                <a href="login.php" class="p1-lg-0 p-3 text-white text-uppercase" style="font-size: 1.8vw">Login</a>
            </li>
        </ul>
    </div>
</nav>

<?php
}
?>