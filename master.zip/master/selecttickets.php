<?php
session_start();
$_SESSION['currentpage'] = "selecttickets";

$pagetitle = "View Orders";

require_once 'header.php';
require_once 'connect.php';

//NECESSARY VARIABLES
$table_err = "";
$date_err = "";
$type_err = "";
$emp_err = "";


// if the user is logged in, search for their tickets
if(isset($_SESSION['custloginid']))
{
    $custid = $_SESSION['custloginid'];

    $formfield['ffemp'] = trim($_POST['emp']);
    $formfield['fftable'] = trim($_POST['table']);
    $formfield['fftypeid'] = trim($_POST['tickettype']);
    $formfield['ffdate'] = ($_POST['ticketdate']);
    $formfield['ffstatus'] = trim($_POST['status']);


    try
    {
        $tickets = "SELECT * FROM ticket WHERE empid like CONCAT('%', :bvempid, '%')
                            AND tickettable like CONCAT('%', :bvtickettable, '%')
                            AND tickettypeid like CONCAT('%', :bvtypeid, '%')
                            AND ticketdate like CONCAT('%', :bvticketdate, '%')
                            AND ticketclosed like CONCAT('%', :bvticketclosed, '%')
                            AND custid = :bvcustid;";
        $result_tickets = $db->prepare($tickets);
        $result_tickets->bindValue(':bvempid', $formfield['ffemp']);
        $result_tickets->bindValue(':bvtickettable', $formfield['fftable']);
        $result_tickets->bindValue(':bvtypeid', $formfield['fftypeid']);
        $result_tickets->bindValue(':bvticketdate', $formfield['ffdate']);
        $result_tickets->bindValue(':bvticketclosed', $formfield['ffstatus']);
        $result_tickets->bindValue(':bvcustid', $custid);
        $result_tickets->execute();

    } catch(PDOException $e)
    {
        echo 'Error!' .$e->getMessage();
        exit();
    }
}


$menu_arr = array();

$item_price = 0;

// get the employees
$employees = 'SELECT * FROM employees';
$result_emp = $db->prepare($employees);
$result_emp->execute();

// get the menu items
$menuitems = 'SELECT * FROM menu';
$result_menu = $db->prepare($menuitems);
$result_menu->execute();

// get the ticket types
$types = 'SELECT * FROM tickettype';
$result_type = $db->prepare($types);
$result_type->execute();

if( isset($_POST['submit']))
{
    $formfield['ffemp'] = trim($_POST['emp']);
    $formfield['fftable'] = trim($_POST['table']);
    $formfield['fftypeid'] = trim($_POST['tickettype']);
    $formfield['ffdate'] = ($_POST['ticketdate']);
    $formfield['ffstatus'] = trim($_POST['status']);


    try
    {
        $tickets = "SELECT * FROM ticket WHERE empid like CONCAT('%', :bvempid, '%')
                            AND tickettable like CONCAT('%', :bvtickettable, '%')
                            AND tickettypeid like CONCAT('%', :bvtypeid, '%')
                            AND ticketdate like CONCAT('%', :bvticketdate, '%')
                            AND ticketclosed like CONCAT('%', :bvticketclosed, '%')
                            AND custid = :bvcustid;";
        $result_tickets = $db->prepare($tickets);
        $result_tickets->bindValue(':bvempid', $formfield['ffemp']);
        $result_tickets->bindValue(':bvtickettable', $formfield['fftable']);
        $result_tickets->bindValue(':bvtypeid', $formfield['fftypeid']);
        $result_tickets->bindValue(':bvticketdate', $formfield['ffdate']);
        $result_tickets->bindValue(':bvticketclosed', $formfield['ffstatus']);
        $result_tickets->bindValue(':bvcustid', $custid);
        $result_tickets->execute();

    } catch(PDOException $e)
    {
        echo 'Error!' .$e->getMessage();
        exit();
    }
}

if(isset($_SESSION['custloginid'])) {
    ?>

    <div class="container">
        <div class="row">
            <div class="card card-body bg-light mt-5">
                <h2>Search tickets</h2>
                <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>" name="form">
                    <div class="row align-content-center">
                        <div class="form-group col w-50">
                            <label for="table">Table:</label>
                            <input type="text" name="table" id="table" class="form-control form-control-md" placeholder="Table"
                                   value="<?php if (isset($formfield['fftable'])) {
                                       echo $formfield['fftable'];
                                   } ?>"/>
                        </div>
                        <div class="form-group col w-50">
                            <label for="ticketdate">Date:</label>
                            <input type="date" name="ticketdate" id="ticketdate" class="form-control form-control-md"
                                   value="<?php if (isset($formfield['ffdate'])) {
                                       echo $formfield['ffdate'];
                                   }; ?>"/>
                        </div>
                    </div>
                    <div class="row align-content-center">
                        <div class="form-group col w-50">
                            <label for="emp">Server:</label>
                            <select name="emp" id="emp"
                                    class="form-control form-control-md <?php echo (!empty($emp_err)) ? 'is-invalid' : ''; ?>">
                                <option value="">Select Server</option>
                                <?php
                                while ($rowe = $result_emp->fetch()) {
                                    if ($rowe['empid'] == $formfield['ffemp']) {
                                        $checker = 'selected';
                                    } else {
                                        $checker = '';
                                    }
                                    echo '<option value="' . $rowe['empid'] . '" ' . $checker . '>' . $rowe['empfname'] . ' ' . $rowe['emplname'] . '</option>';
                                }
                                ?>
                            </select>
                            <span class="invalid-feedback"><?php echo $emp_err; ?></span>
                        </div>
                        <div class="form-group col w-25">
                            <label for="tickettype">Ticket Type:</label>
                            <select name="tickettype" id="tickettype"
                                    class="form-control form-control-md <?php echo (!empty($type_err)) ? 'is-invalid' : ''; ?>">
                                <option value="">Select Type</option>
                                <?php
                                while ($rowt = $result_type->fetch()) {
                                    if ($rowt['tickettypeid'] == $formfield['fftypeid']) {
                                        $checker = 'selected';
                                    } else {
                                        $checker = '';
                                    }
                                    echo '<option value="' . $rowt['tickettypeid'] . '" ' . $checker . '>' . $rowt['typedescr'] . '</option>';
                                }
                                ?>
                            </select>
                            <span class="invalid-feedback"><?php echo $type_err; ?></span>
                        </div>
                        <div class="form-group col w-25">
                            <label for="status">Ticket Status:</label>
                            <select name="status" id="status" class="form-control form-control-md">
                                <option value="">Select Status</option>
                                <?php
                                if (isset($formfield['ffstatus']) && $formfield['ffstatus'] != null) {
                                    if ($formfield['ffstatus'] == 0) {
                                        echo '<option value="0" selected>Open</option>';
                                        echo '<option value="1">Closed</option>';
                                    } else {
                                        echo '<option value="0">Open</option>';
                                        echo '<option value="1" selected>Closed</option>';
                                    }
                                } else {

                                    echo '<option value="0">Open</option>';
                                    echo '<option value="1">Closed</option>';
                                }
                                ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-row justify-content-center">
                        <div class="col text-center">
                            <input type="submit" value="Submit" name="submit" class="btn btn-secondary">
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <br><br>

    <div class="align-content-center container">
        <table class="table table-hover">
            <thead class="thead-light">
            <tr>
                <th>Ticket ID</th>
                <th>Table</th>
                <th>Server Last Name</th>
                <th>Date & Time</th>
                <th>Ticket Type</th>
                <th>Status</th>
                <th>Edit</th>
                <th>Edit Ticket Items</th>
            </tr>
            </thead>
            <tbody>
            <?php
            while ($row = $result_tickets->fetch()) {
                try {
                    $empid = $row['empid'];

                    $getemplname = "SELECT * FROM employees WHERE empid = '" . $empid . "'";
                    $result_lname = $db->prepare($getemplname);
                    $result_lname->execute();
                    $emplname = "";

                    while ($r = $result_lname->fetch()) {
                        $emplname = $r['emplname'];
                    }

                    $typeid = $row['tickettypeid'];

                    $sqlgettype = "SELECT * FROM tickettype WHERE tickettypeid = '" . $typeid . "'";
                    $result_type = $db->prepare($sqlgettype);
                    $result_type->execute();
                    $type = "";

                    while ($t = $result_type->fetch()) {
                        $type = $t['typedescr'];
                    }

                    echo '<tr><th scope="row">' . $row['ticketid'] . '</th>';
                    echo '<td>' . $row['tickettable'] . '</td>';
                    echo '<td>' . $emplname . '</td>';
                    echo '<td>' . $row['ticketdate'] . '</td>';
                    echo '<td>' . $type . '</td>';


                    if ($row['ticketclosed'] == 0) {
                        echo '<td>Open</td>';

                        echo '<td><form action="updateticket.php" method="post">';
                        echo '<input type="hidden" name="ticketid" value="' . $row['ticketid'] . '">';
                        echo '<input type="submit" name="theedit" class="btn btn-sm btn-secondary" value="Edit">';
                        echo '</form></td>';
                        echo '<td><form action="insertticketdetails.php" method="post">';
                        echo '<input type="hidden" name="ticketid" value="' . $row['ticketid'] . '">';
                        echo '<input type="submit" name="thesubmit" class="btn btn-sm btn-secondary" value="Edit Ticket Items">';
                        echo '</form></td>';
                    } else {
                        echo '<td>Closed</td>';
                    }

                    echo '</tr>';

                } catch (PDOException $e) {
                    echo 'Error!  ' . $e->getMessage();
                    exit();
                }
            }
            ?>
            </tbody>
        </table>
    </div><br><br>
    <?php
}
include_once 'footer.php';
?>