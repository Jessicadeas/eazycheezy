<?php
$pagetitle = "Login Confirmation";
require_once 'header.php';
require_once 'connect.php';

if(isset($_SESSION['frontloginid']))
{
    echo "<br><h3>";
    echo '<div class="text-center text-white">';
    echo "<p class='error'>You are already logged in.</p>";
	echo '<a href = "frontindex.php">Continue</a>';
    echo "</div></h3><br>";
    include_once 'footer.php';
    exit();
}

$showform = 1;
$errormsg = '';

if(isset ($_POST['submit'])) {
	
	$formfield['ffemail'] = strtolower(trim($_POST['BBemail']));
	$formfield['ffpassword'] = trim($_POST['BBpassword']);
	
	if(empty($formfield['ffemail'])) { $errormsg .= '<p>EMAIL IS MISSING</p>';}
	if(empty($formfield['ffpassword'])) { $errormsg .= '<p>PASSWORD IS MISSING</p>';}
	
	if($errormsg != '') {
		echo "<p>THERE ARE ERRORS</p>" . $errormsg;
	}
	else
	{
		try
		{
			$sql = 'SELECT * FROM customer WHERE dbcustemail = :bvemail';
			$s = $db->prepare($sql);
			$s->bindValue(':bvemail', $formfield['ffemail']);
			$s->execute();
			$count = $s->rowCount();
		}
		catch (PDOException $e)
		{
			echo "ERROR!!!" . $e->getMessage();
			exit();
		}
		
		if($count < 1)
		{
			echo '<p>The email or password is incorrect</p>';
		}
		else 
		{
			$row = $s->fetch();
			$confirmeduname = $row['dbcustemail'];
			$confirmedpw = $row['dbcustpassword'];
			
			if (password_verify($formfield['ffpassword'], $confirmedpw))
			{
				$_SESSION['frontloginid']= $row['dbcustid'];
                $_SESSION['frontloginname'] = $row['dbcustfname'];
				$showform = 0;
				echo "<br><h3>";
				echo '<div class="text-center text-white">';
                echo "Logged In Successfully";
				echo "<br><br>";
				echo '<a href = "index.php">Continue</a>';
				echo "</div></h3><br>";

				echo '<script type="text/javascript">';
				echo 'function Redirect(){';
				echo '  window.location="index.php";';
				echo '}';
				echo '  setTimeout("Redirect()", 250);';
				echo '</script>';

			} 
			else
			{
				echo '<p>The emails or password is incorrect</p>';
			}
		}
	}
}
if($showform == 1)
{
?>
<br>
<div class="container-fluid text-center">
    <h1 class="display-4 text-white" style="font-family: AvenirLTStd-Roman">Log in or <span style="text-decoration: underline"><a href="register.php" class="text-white text">Register</a></span></h1>
    <div class="row">
        <div class="col-md-4 mx-auto">
            <div class="card card-body mt-5">
                <h5>You are not logged in. Please log in.</h5><br>
                <form name="loginForm" id="loginForm" method="post" action="login.php" class="text-lg-center">
                    <div class="form-group">
                        <label for="BBemail">Email:</label>
                        <input type="email" name="BBemail" id="email" class="form-control" required placeholder="E-mail">
                    </div>
                    <div class="form-group">
                        <label for="BBpassword">Password:</label>
                        <input type="password" name="BBpassword" id="password" class="form-control" required placeholder="Password">
                    </div>
                    <div class="text-center">
                        <input type="submit" name="submit" value="Log In" class="btn btn-md btn-dark">
                        <a href="register.php" class="btn btn-light">No Account? Register</a>
                    </div>
                </form>
            </div>
        </div>

    </div>
</div>
    <br><br>


<?php
}
include_once 'footer.php';
?>