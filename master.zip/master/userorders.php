<?php
session_start();
$_SESSION['currentpage'] = "userorders";

$pagetitle = "View Your Orders";

require_once 'header.php';
require_once 'connect.php';

$custid = $_SESSION['frontloginid'];
$visible = 1;

try
{
    $tickets = "SELECT t.dbticketid, tt.dbtickettypename, t.dbticketdate, t.dbticketnotes, t.dbticketclosed, l.dblocationname  
                      FROM ticket t, tickettype tt, locations l WHERE t.dbticketlocation = l.dblocationid AND t.dbtickettypeid = tt.dbtickettypeid AND t.dbcustid = :bvcustid ";
    $result_tickets = $db->prepare($tickets);
    $result_tickets->bindValue(':bvcustid', $custid);
    $result_tickets->execute();

} catch(PDOException $e)
{
    echo 'Error!' .$e->getMessage();
    exit();
}

if(isset($_SESSION['frontloginid'])) {
    ?>

    <br>
<div>

</div>
    <div class="container bg-white rounded-lg">
        <br>
            <center><h2 class="text-warning font-weight-bold">View Your Orders</h2></center>

        <br>

        <center>
            <table class="table table-responsive-sm table-striped w-auto table-hover bg-white display rounded-lg" id="tickets">
                <thead class="thead-light">
                <tr>
                    <th>Order&nbsp;ID</th>
                    <th>Order&nbsp;Type</th>
                    <th>Date&nbsp;of&nbsp;Order</th>
                    <th>Order&nbsp;Notes</th>
                    <th>Location</th>
                    <th>Status</th>
                    <th></th>
                    <th></th>
                </tr>
                </thead>
                <tbody>
                <?php
                while ($row = $result_tickets->fetch()) {
                    try {

                        echo '<tr><th scope="row">' . $row['dbticketid'] . '</th>';
                        echo '<td>' . $row['dbtickettypename'] . '</td>';
                        echo '<td>' . $row['dbticketdate'] . '</td>';
                        echo '<td>' . $row['dbticketnotes'] . '</td>';
                        echo '<td>' . $row['dblocationname'] . '</td>';

                        if ($row['dbticketclosed'] == 0) {
                            echo '<td>Open</td>';

                            echo '<td><form action="insertticketdetails.php" method="post">';
                            echo '<input type="hidden" name="ticketid" value="' . $row['dbticketid'] . '">';
                            echo '<input type="submit" name="thesubmit" class="btn btn-sm btn-secondary" value="Edit Order Items">';
                            echo '</form></td>';
                        } else {
                            echo '<td>Closed</td>';

                            echo '<td><form action="insertticketdetails.php" method="post">';
                            echo '<input type="hidden" name="ticketid" value="' . $row['dbticketid'] . '">';
                            echo '<input type="hidden" name="thesubmit" class="btn btn-sm btn-secondary" value="Edit Ticket Items" disabled>';
                            echo '</form></td>';
                        }

                        echo '<td><form action="viewuserorderdetails.php" method="post">';
                        echo '<input type="hidden" name="ticketid" value="' . $row['dbticketid'] . '">';
                        echo '<input type="submit" name="view" class="btn btn-sm btn-secondary" value="View Details">';
                        echo '</form></td>';

                        echo '</tr>';

                    } catch (PDOException $e) {
                        echo 'Error!  ' . $e->getMessage();
                        exit();
                    }
                }
                ?>
                </tbody>
            </table>
        </center>


        <script>
            $(document).ready( function () {
                $('#tickets').DataTable();
            } );
        </script>

    </div><br><br>
    <?php
}
include_once 'footer.php';
?>