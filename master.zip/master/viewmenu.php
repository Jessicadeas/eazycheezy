<?php
session_start();
$_SESSION['currentpage'] = "menu";

$pagetitle = "Menu";

require_once 'header.php';
require_once 'connect.php';

//NECESSARY VARIABLES

$categories = 'SELECT * FROM category';
$resultc = $db->prepare($categories);
$resultc->execute();

$menuitems = 'SELECT * FROM menu';
$resultm = $db->prepare($menuitems);
$resultm->execute();


?>

    <br><br>

    <div class="container">
        <?php
        while ($rowc = $resultc->fetch()) {
            echo '<h1 style="font-family: Baron-Neue" class="font-italic text-warning text-lowercase">' . $rowc['dbcatname'] . '</h1><table class="table text-white" style="font-family:AvenirLTStd-Roman">';
            while ($rowm = $resultm->fetch()) {
                if ($rowc['dbcatid'] == $rowm['dbcatid']) {
                    echo '<tr><td style="width:25%">' . $rowm['dbmenuitemname'] . '</td><td style="width:65%">' . $rowm['dbmenuitemdescr'] . '</td><td style="width:10%">$' . $rowm['dbmenuitemprice'] . '</td></tr>';
                }
            }
            $resultm = $db->prepare($menuitems);
            $resultm->execute();
            echo '</table><br>';
        }
        ?>
    </div>
<?php

include_once 'footer.php';
?>