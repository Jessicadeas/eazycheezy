<?php
session_start();
$_SESSION['currentpage'] = "enterticket";

$pagetitle = "Enter Order";

require_once 'header.php';
require_once 'connect.php';


//NECESSARY VARIABLES
$type_err = $date_err = $tickettime_err = $location_err = "";
$showform = 1;

$empid_arr = array();
$menu_arr = array();

$item_price = 0;

// get the locations
$locations = 'SELECT * FROM locations';
$result_l = $db->prepare($locations);
$result_l->execute();



// if the user is logged in, set the $custid variable
if(isset($_SESSION['frontloginid']))
{
    $custid = $_SESSION['frontloginid'];
    $visible = 1;

    // get user's preferred location
    $sqlselectlocation = "SELECT dblocationid FROM customer WHERE dbcustid = :bvcustid";
    $result_loc = $db->prepare($sqlselectlocation);
    $result_loc->bindValue(':bvcustid', $custid);
    $result_loc->execute();

    while($r = $result_loc->fetch())
    {
        $formfield['fflocation'] = $r['dblocationid'];
    }

} else {
    $visible = 0;
}

if( isset($_POST['submit']))
{
    $formfield['fftypeid'] = $_POST['tickettype'];

    if($formfield['fftypeid'] == 2)
    {
        try {

            $sqlselectaddress = "SELECT dbcustaddress1, dbcustcity, dbcuststate, dbcustzip, dbcustphone, dblocationid FROM customer where dbcustid = :bvcustid ";
            if($user_address = $db->prepare($sqlselectaddress)) {
                $user_address->bindValue(':bvcustid', $custid);
                if ($user_address->execute()) {
                    while ($row = $user_address->fetch()) {
                        if ($row['dbcustaddress1'] == null || $row['dbcustaddress1'] == "" ||
                            $row['dbcustcity'] == null || $row['dbcustcity'] == "" ||
                            $row['dbcuststate'] == null || $row['dbcuststate'] == "" ||
                            $row['dbcustzip'] == null || $row['dbcustzip'] == "" ||
                            $row['dbcustphone'] == null || $row['dbcustphone'] == "" ||
                            $row['dblocationid'] == null || $row['dblocationid'] == "") {
                            echo '<br><div class="alert alert-warning" style="width:40%; margin: 0 30% 0 30%; text-align:center role="alert">To place a delivery order, please go to <a href="updateuser.php">User Information</a> and enter your address and phone number. Thank you.</div><br>';
                        } else {

                            $formfield['ffdate'] = ($_POST['ticketdate']);
                            $formfield['fftickettime'] = ($_POST['tickettime']);
                            $formfield['ffticketnotes'] = trim($_POST['ticketnotes']);
                            $formfield['ffticketlocation'] = ($_POST['location']);

                            if (empty($formfield['fftypeid'])) {
                                $type_err = "Order type cannot be empty.";
                            }

                            if (empty($formfield['fftickettime'])) {
                                $tickettime_err = "Delivery & Pickup hours are 11 AM to 10 PM.";
                            }

                            if (empty($type_err) && empty($date_err)) {
                                try {
                                    $sqlmax = "SELECT MAX(dbticketid) AS maxid FROM ticket";
                                    $resultmax = $db->prepare($sqlmax);
                                    $resultmax->execute();
                                    $rowmax = $resultmax->fetch();
                                    $maxid = $rowmax["maxid"];
                                    $maxid = $maxid + 1;

                                    $sqlinsert = "INSERT into ticket (dbticketid, dbcustid, dbtickettypeid, dbticketdate, dbtickettime, dbticketnotes, dbticketclosed, dbticketlocation)
                    VALUES (:bvticketid, :bvcustid, :bvtypeid, now(), :bvtickettime, :bvticketnotes, 0,:bvticketlocation)";
                                    $sqlinsert = $db->prepare($sqlinsert);
                                    $sqlinsert->bindValue(':bvticketid', $maxid);
                                    $sqlinsert->bindValue(':bvcustid', $custid);
                                    $sqlinsert->bindValue(':bvtypeid', $formfield['fftypeid']);
                                    $sqlinsert->bindValue(':bvtickettime', $formfield['fftickettime']);
                                    $sqlinsert->bindValue(':bvticketnotes', $formfield['ffticketnotes']);
                                    $sqlinsert->bindValue(':bvticketlocation', $formfield['ffticketlocation']);
                                    $sqlinsert->execute();

                                    echo '<div class="container text-center">';
                                    echo '<div class="row">';
                                    echo '<div class="card card-body bg-light mt-5">';
                                    echo '<h2>Order Number ' . $maxid . '</h2>';
                                    echo '<form method="post" action="insertticketdetails.php">';
                                    echo '<input type="hidden" name="ticketid" value="' . $maxid . '">';
                                    echo '<input type="submit" name="thesubmit" class="btn btn-warning font-weight-bold" value="Enter Order Items">';
                                    echo '</form>';
                                    echo '</div>';
                                    echo '</div>';
                                    echo '</div>';
                                    $showform = 0;

                                } catch (PDOException $e) {
                                    echo 'Error!' . $e->getMessage();
                                    exit();
                                }
                            }
                        }
                    }
                } else {
                    die("Something went wrong");
                }
            }
            unset($select_stmt);


        } catch (PDOException $e) {
            echo 'Error!' .$e->getMessage();
            exit();
        }
    } else {
        $formfield['ffdate'] = ($_POST['ticketdate']);
        $formfield['fftickettime'] = ($_POST['tickettime']);
        $formfield['ffticketnotes'] = trim($_POST['ticketnotes']);
        $formfield['fflocation'] = ($_POST['location']);

        if(empty($formfield['fftypeid'])) {
            $type_err = "Order type cannot be empty.";
        }

        if(empty($formfield['fftickettime'])) {
            $tickettime_err = "Delivery & Pickup hours are 11 AM to 10 PM.";
        }

        if(empty($formfield['fflocation'])) {
            $location_err = "Please select location.";
        }

        if(empty($type_err) && empty($date_err) && empty($location_err))
        {
            try
            {
                $sqlmax = "SELECT MAX(dbticketid) AS maxid FROM ticket";
                $resultmax = $db->prepare($sqlmax);
                $resultmax->execute();
                $rowmax = $resultmax->fetch();
                $maxid = $rowmax["maxid"];
                $maxid = $maxid + 1;

                $sqlinsert = "INSERT into ticket (dbticketid, dbcustid, dbtickettypeid, dbticketdate, dbtickettime, dbticketnotes, dbticketclosed, dbticketlocation)
                    VALUES (:bvticketid, :bvcustid, :bvtypeid, now(), :bvtickettime, :bvticketnotes, 0,:bvticketlocation)";
                $sqlinsert = $db->prepare($sqlinsert);
                $sqlinsert->bindValue(':bvticketid', $maxid);
                $sqlinsert->bindValue(':bvcustid', $custid);
                $sqlinsert->bindValue(':bvtypeid', $formfield['fftypeid']);
                $sqlinsert->bindValue(':bvtickettime', $formfield['fftickettime']);
                $sqlinsert->bindValue(':bvticketnotes', $formfield['ffticketnotes']);
                $sqlinsert->bindValue(':bvticketlocation', $formfield['fflocation']);
                $sqlinsert->execute();

                echo '<div class="container text-center">';
                echo    '<div class="row">';
                echo        '<div class="card card-body bg-light mt-5">';
                echo        '<h2>Order Number ' . $maxid . '</h2>';
                echo        '<form method="post" action="insertticketdetails.php">';
                echo        '<input type="hidden" name="ticketid" value="' . $maxid . '">';
                echo        '<input type="submit" name="thesubmit" class="btn btn-warning font-weight-bold" value="Enter Order Items">';
                echo        '</form>';
                echo        '</div>';
                echo    '</div>';
                echo '</div>';
                $showform = 0;

            } catch(PDOException $e)
            {
                echo 'Error!' .$e->getMessage();
                exit();
            }
        }
    }


}

if(isset($_SESSION['frontloginid']) && $visible == 1 && $showform != 0) {
    ?>

    <div class="container">
        <div class="row">
            <div class="card card-body bg-light mt-5">
                <h2 class="text-center">Enter Order</h2>
                <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>" name="form">
                    <p class="text-center">We only do same day pickup/delivery orders online.</p>
                    <p class="text-center">For all other orders, please call (843) 123-4567.</p>
                    <hr>
                    <div class="row align-content-center">

                        <div class="form-group col w-50">
                            <form
                            <label for="choosetype">Order Type:</label>
                            <div id="choosetype" class="row w-75 text-center">
                                <div class="col custom-control custom-radio">
                                    <input type="radio" id="pickup" name="tickettype" class="custom-control-input" value="3" checked>
                                    <label class="custom-control-label" for="pickup">Pickup</label>
                                </div>
                                <div class="col custom-control custom-radio">
                                    <input type="radio" id="delivery" name="tickettype" class="custom-control-input" value="2">
                                    <label class="custom-control-label" for="delivery">Delivery</label>
                                </div>
                            </div>

                        </div>
						
						<div class="form-group col">
                            <label for="location">Preferred Location:</label>

                            <select name="location" id="location" required
                                    class="form-control <?php echo (!empty($location_err)) ? 'is-invalid' : ''; ?>">
                                <option value="0">Select Location</option>
                                <?php
                                while ($rowl = $result_l->fetch())
                                {
                                    if ($rowl['dblocationid'] == $formfield['fflocation']) {
                                        $checker = 'selected';
                                    } else {
                                        $checker = '';
                                    }
                                    echo '<option value="' . $rowl['dblocationid'] . '" ' . $checker . '>' . $rowl['dblocationname'] . '</option>';
                                }
                                ?>
                            </select>
                            <span class="invalid-feedback"><?php echo $location_err; ?></span>

                        </div>
                        <div class="form-group col">
                            <label for="tickettime">Delivery/Pickup Time:</label>
                            <input type="time" id="tickettime" name="tickettime" class="form-control" min="11:00" max="22:00"
                                   value="<?php if (isset($formfield['fftickettime'])) {
                                       echo $formfield['fftickettime'];
                                   } else { echo date("H:i", strtotime('2 hour'));
                                   } ?>" />
                            <span class="invalid-feedback"><?php echo $tickettime_err; ?></span>
                        </div>
                    </div>
                    <div class="row align-content-center">

                        <div class="form-group col w-50">
                            <label for="ticketnotes">Order Notes:</label>
                            <input type="text" name="ticketnotes" id="ticketnotes" maxlength="255" placeholder="Food allergies, special requests, special delivery instructions (E.g. gate code), etc."
                                   class="form-control"
                                   value="<?php if (isset($formfield['ffticketnotes'])) {
                                       echo $formfield['ffticketnotes'];
                                   } ?>"/>
                        </div>
                    </div>

                    <div class="form-row justify-content-center">
                        <div class="text-center">
                            <input type="submit" value="Submit" name="submit" class="btn btn-secondary">
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <br><br>
    <?php
} else if($showform == 1 && $visible == 0){
    ?>
    <div class="justify-content-center text-center">
        <div class="card text-white bg-dark mb-3 d-inline-block">
            <div class="card-body">
                <h4 class="card-title">Sorry</h4>
                <h6 class="card-subtitle mb-2 text-muted">Cannot place an order</h6>
                <p class="card-text">
                    To place an order, please register.
                </p>
                <a href="register.php" class="card-link">Register</a>
            </div>
        </div>
    </div>

    <?php
}
include_once 'footer.php';
?>