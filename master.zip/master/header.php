<?php
session_start();
?>
<!--This header is attached to every page on the front-end website. Styles and functionality are selected
    to improve the user experience as much as possible. While it wasn't required of us, Bootstrap and Jquery are
    used moderately throughout this project in an effort to familiarize ourselves with resources that would be
    heavily utilized in real-world scenarios. -->
<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="utf-8">
    <link rel="shortcut icon" size="16x16" type="image/x-icon" href="images/fave_icon_EZ.ico?" />
    <link rel="stylesheet" href="styles/bootstrap4-wizardry.css" />
    <link rel="stylesheet" href="styles/datatables.min.css"/>
    <link rel="stylesheet" href="styles/dataTables.bootstrap.min.css" />
    <link href="styles/dataTables.bootstrap4.min.css" type="text/css" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css"
          integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
    
    <script src="js/jquery-3.3.1.min.js"></script>
    <!-- MDBootstrap Datatables  -->
    <script type="text/javascript" charset="utf8" src="js/datatables.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="js/bootstrap.js"></script>

</head>

<!-- body closed in the footer -->
<body id="page-container"
      style="background-image:url(images/background_cropped.png);
      background-repeat:no-repeat;
      background-attachment: fixed;
      background-size: 100% 100%;
      background-color: rgba(0,0,0,0.42)">

<!--Used in conjunction with the #page-container to format front-end pages. This ID adds padding-bottom-->
<div id="content-wrap">

    <!--div to hold the navigation and Logo. Add a darker but slightly opaque background for easier legibility-->
    <div class="border border border-white border-left-0 border-top-0 border-right-0"
         style="background:rgba(34,35,45,0.90)">

        <!--Padded container row to hold the logo and navbar in a grid row-->
        <div class="row container-fluid text-center p-2">

            <div class="top-right">
                <kbd style="font-family: AvenirLTStd-Roman">
                    Welcome <?php echo $_SESSION['frontloginname']; ?>
                </kbd>
            </div>

            <!--Left column will be the EZ cheezy logo which acts as a link to the home page-->
            <div class="col-2">
                <div class="img-fluid"><a href="index.php"><image src="images/white_logo.png" width="90%" alt="Thumbnail image of Ez Cheezy Logo"/></a>
                </div>
            </div>

            <!--Second column right-aligns the results of the navbar.php page which is called here-->
            <div class="col-10 d-flex justify-content-sm-end align-items-end">
                <?php include_once "navbar.php" ?>
            </div>
        </div>
    </div>

    <!--This final div holds the remainder of the page contents with a small margin. Closed in the footer -->
    <div style="margin-left:1%;margin-right:1%">
